

# UserProfile

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**email** | **String** | The users email address |  [optional]
**forename** | **String** | The users forename |  [optional]
**id** | **String** | The users unique ID | 
**locale** | **String** | The users chosen locale |  [optional]
**surname** | **String** | The users surname |  [optional]




